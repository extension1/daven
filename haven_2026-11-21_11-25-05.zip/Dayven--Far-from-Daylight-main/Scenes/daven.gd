extends CharacterBody2D
# Godot 4 version.

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

const SPEED = 350

# --- bounce aiming ---
const SLOWMO_SCALE = 0.25        # Engine.time_scale while aiming
const LAUNCH_SPEED = 600.0       # constant bounce speed, the drag only picks direction
const MIN_PULL = 20.0            # drag shorter than this = cancelled launch

# --- aim visuals ---
const RING_RADIUS = 68.0
const DOT_START = 60.0           # dots begin this far from Daven's center
const DOT_SPACING = 16.0
const PREVIEW_LEN = 320.0        # how far the preview looks for the first wall
const PREVIEW_BOUNCE_LEN = 160.0 # length of the "after bounce" preview
const COLOR_AIM = Color(1, 0.75, 0.25)

enum State { NORMAL, AIMING, BOUNCING }

var state: State = State.NORMAL
var lightblocker: int = 0        # breakable tiles left, counted at _ready
var won: bool = false

var dragging: bool = false
var drag_start: Vector2 = Vector2.ZERO
var aim_vector: Vector2 = Vector2.ZERO  # launch direction (slingshot: opposite of the drag)

# preview data (computed in the physics step, drawn in _draw)
var preview_hit_point: Vector2 = Vector2.ZERO
var preview_bounce_end: Vector2 = Vector2.ZERO
var preview_has_bounce: bool = false

func _ready() -> void:
	velocity = Vector2(-SPEED, 0)
	lightblocker = count_breakables(get_tree().root)

func _exit_tree() -> void:
	Engine.time_scale = 1.0

func _physics_process(delta: float) -> void:
	# W: NORMAL -> AIMING, AIMING -> cancel, BOUNCING -> back to normal
	if Input.is_action_just_pressed("bounce"):
		if state == State.NORMAL:
			_set_state(State.AIMING)
		else:
			_set_state(State.NORMAL)

	match state:
		State.AIMING:
			# slow-mo: Daven keeps moving/falling, you can still walk while lining up the shot
			_move_normal(delta)
			_process_aiming()
		State.BOUNCING:
			var col := move_and_collide(velocity * delta)
			if col:
				check_breakable_tile(col)
				velocity = velocity.bounce(col.get_normal())
		State.NORMAL:
			_move_normal(delta)

	_update_animation()

func _move_normal(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

# ---------- state handling ----------

func _set_state(new_state: State) -> void:
	if new_state == state:
		return
	if state == State.AIMING:
		_end_aiming()
	state = new_state
	if state == State.AIMING:
		_begin_aiming()

func _begin_aiming() -> void:
	dragging = false
	aim_vector = Vector2.ZERO
	preview_has_bounce = false
	Engine.time_scale = SLOWMO_SCALE
	queue_redraw()

func _end_aiming() -> void:
	Engine.time_scale = 1.0
	dragging = false
	aim_vector = Vector2.ZERO
	preview_has_bounce = false
	queue_redraw()

func _process_aiming() -> void:
	var mouse_down: bool = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	var mouse_pos: Vector2 = get_viewport().get_mouse_position()

	if mouse_down and not dragging:
		dragging = true
		drag_start = mouse_pos

	if dragging:
		# slingshot: pull back, launch the opposite way
		aim_vector = drag_start - mouse_pos

		if not mouse_down:
			# released
			if aim_vector.length() >= MIN_PULL:
				velocity = aim_vector.normalized() * LAUNCH_SPEED
				_set_state(State.BOUNCING)
				return
			# too short -> cancel this drag, stay in aiming
			dragging = false
			aim_vector = Vector2.ZERO
		elif aim_vector.length() >= MIN_PULL:
			_update_preview()

	queue_redraw()  # redraw the aim visuals

# Test-only move along the aim direction: finds where the body would hit a wall
# and which way it would bounce off.
func _update_preview() -> void:
	var dir: Vector2 = aim_vector.normalized()
	var hit: KinematicCollision2D = move_and_collide(dir * PREVIEW_LEN, true)
	if hit:
		preview_hit_point = hit.get_travel()
		var reflected: Vector2 = dir.bounce(hit.get_normal())
		preview_bounce_end = preview_hit_point + reflected * PREVIEW_BOUNCE_LEN
		preview_has_bounce = true
	else:
		preview_hit_point = dir * PREVIEW_LEN
		preview_has_bounce = false

# ---------- drawing ----------

func _draw() -> void:
	if state != State.AIMING:
		return

	# faint ring = "you're in aim mode"
	draw_arc(Vector2.ZERO, RING_RADIUS, 0.0, TAU, 64, Color(1, 1, 1, 0.2), 2.0, true)

	if not dragging or aim_vector.length() < MIN_PULL:
		return

	var tint: Color = COLOR_AIM
	var dir: Vector2 = aim_vector.normalized()

	# ring lights up once the drag is long enough to count as a shot
	draw_arc(Vector2.ZERO, RING_RADIUS, 0.0, TAU, 64, tint, 4.0, true)

	# marching dots toward the first wall, fading out with distance
	_draw_dots(dir * DOT_START, preview_hit_point, tint, 1.0)

	if preview_has_bounce:
		# impact marker + fainter dots for the bounced path
		draw_circle(preview_hit_point, 9.0, Color(tint.r, tint.g, tint.b, 0.3))
		draw_circle(preview_hit_point, 4.0, tint)
		_draw_dots(preview_hit_point, preview_bounce_end, tint, 0.5)

func _draw_dots(from: Vector2, to: Vector2, tint: Color, strength: float) -> void:
	var d: Vector2 = to - from
	var length: float = d.length()
	if length < 1.0:
		return
	var dir: Vector2 = d / length
	var dist: float = fposmod(float(Time.get_ticks_msec()) * 0.03, DOT_SPACING)  # makes the dots march
	while dist < length:
		var t: float = dist / length
		var alpha: float = lerpf(1.0, 0.25, t) * strength
		var radius: float = lerpf(4.0, 2.0, t)
		draw_circle(from + dir * dist, radius, Color(tint.r, tint.g, tint.b, alpha))
		dist += DOT_SPACING

# ---------- animation ----------

func _update_animation() -> void:
	if state == State.BOUNCING or absf(velocity.x) > 1.0:
		animated_sprite_2d.play("Walk")
		if velocity.x < 0:
			animated_sprite_2d.flip_h = true
		elif velocity.x > 0:
			animated_sprite_2d.flip_h = false
	else:
		animated_sprite_2d.play("Idle")

# ---------- breakable tiles ----------

func check_breakable_tile(collision: KinematicCollision2D) -> void:
	var layer := collision.get_collider() as TileMapLayer
	if layer == null:
		return

	var hit_pos: Vector2 = collision.get_position() - collision.get_normal()
	var tile_coords: Vector2i = layer.local_to_map(layer.to_local(hit_pos))

	var tile_data: TileData = layer.get_cell_tile_data(tile_coords)
	if tile_data and tile_data.get_custom_data("breakable"):
		layer.erase_cell(tile_coords)
		lightblocker -= 1

		if lightblocker <= 0 and not won:
			won = true
			get_tree().change_scene_to_file("res://Scenes/cut.tscn")

# Counts every tile flagged "breakable" in every TileMapLayer under `node`.
func count_breakables(node: Node) -> int:
	var total := 0
	var layer := node as TileMapLayer
	if layer:
		for cell in layer.get_used_cells():
			var tile_data: TileData = layer.get_cell_tile_data(cell)
			if tile_data and tile_data.get_custom_data("breakable"):
				total += 1
	for child in node.get_children():
		total += count_breakables(child)
	return total
